var secret='abc13nmmAXz321jhfkjdsjdsagdjasg5765@%#a%afsafs$@af'; //your own secret key
var domain='192.168.18.2';
module.exports.key = secret;
module.exports.domain=domain;