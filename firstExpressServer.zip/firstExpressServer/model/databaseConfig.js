var mysql = require('mysql');

var dbconnect = {
getConnection: function() {
    var conn = mysql.createConnection({
    host: "192.168.18.2",
    user: "jklow",
    password: "root",
    database: "kamailio"
});
return conn;
}
};

module.exports = dbconnect